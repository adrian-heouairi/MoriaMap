#!/bin/sh

java -jar ./MoriaMap.jar
